import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "GLOBAL MODELS | International Model & Influencer Agency",
  description: "Leading international model and influencer agency representing top talent worldwide.",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}

