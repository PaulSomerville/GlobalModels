import Hero from "./components/hero"
import Services from "./components/services"
import Contact from "./components/contact"
import Footer from "./components/footer"

export default function HomePage() {
  return (
    <main className="min-h-screen bg-white">
      <Hero />
      <Services />
      <Contact />
      <Footer />
    </main>
  )
}

