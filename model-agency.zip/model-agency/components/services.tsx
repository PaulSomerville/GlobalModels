'use client'

import { motion } from "framer-motion"
import { ArrowRight } from 'lucide-react'

const services = [
  {
    title: "Campaigns",
    description: "Creative direction and talent for advertising campaigns across all media platforms.",
  },
  {
    title: "Influencers",
    description: "Connect with our network of established influencers for authentic brand collaborations.",
  },
  {
    title: "Models",
    description: "Professional models for fashion, commercial, and editorial projects worldwide.",
  },
]

export default function Services() {
  return (
    <section className="py-24">
      <div className="container px-4 md:px-6">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 text-center text-3xl font-bold tracking-tighter sm:text-4xl"
        >
          Our Services
        </motion.h2>
        <div className="grid gap-8 md:grid-cols-3">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
              className="group relative overflow-hidden rounded-lg bg-gray-50 p-6 transition-all hover:bg-gray-100"
            >
              <h3 className="mb-2 text-xl font-semibold">{service.title}</h3>
              <p className="mb-4 text-gray-600">{service.description}</p>
              <motion.div
                whileHover={{ x: 5 }}
                className="flex items-center text-sm font-medium"
              >
                Learn more
                <ArrowRight className="ml-1 h-4 w-4" />
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

