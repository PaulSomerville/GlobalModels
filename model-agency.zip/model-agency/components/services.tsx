<section class="pt-12 pb-24">
  {/* Content of the section */}
</section>

