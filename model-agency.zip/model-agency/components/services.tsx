'use client'

import { motion } from "framer-motion"

const services = [
  {
    title: "Campaigns",
    description: "Creative direction and talent for advertising campaigns across all media platforms.",
  },
  {
    title: "Influencers",
    description: "Connect with our network of established influencers for authentic brand collaborations.",
  },
  {
    title: "Models",
    description: "Professional models for fashion, commercial, and editorial projects worldwide.",
  },
]

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.3,
    },
  },
}

const cardVariants = {
  hidden: { 
    opacity: 0,
    y: 20,
  },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: [0.22, 1, 0.36, 1]
    },
  },
}

export default function Services() {
  return (
    <section className="relative overflow-hidden pt-12 pb-24">
      <div className="container px-4 md:px-6">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 text-center text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl"
        >
          Our Services
        </motion.h2>
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid gap-8 md:grid-cols-3"
        >
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              variants={cardVariants}
              className="group relative overflow-hidden rounded-xl border border-black/5 bg-white p-8 shadow-lg transition-all duration-500 hover:shadow-xl"
            >
              <motion.div
                initial={{ height: 0 }}
                whileHover={{ height: "100%" }}
                className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/[0.03] to-transparent"
                style={{ originY: 1 }}
                transition={{ duration: 0.5 }}
              />
              <h3 className="mb-4 text-2xl font-semibold">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

