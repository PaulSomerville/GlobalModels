'use client'

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Check } from 'lucide-react'
import { useForm } from "react-hook-form"
import { z } from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { Turnstile } from '@marsidev/react-turnstile'

// Enhanced URL validation
const urlRegex = /^(https?:\/\/)?([\w-]+\.)+[\w-]+(\/[\w-./?%&=]*)?$/

// Form validation schema
const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email"),
  companyName: z.string().optional(),
  website: z.string()
    .refine((val) => {
      if (!val) return true // Allow empty
      return urlRegex.test(val)
    }, "Please enter a valid website URL")
    .optional(),
  instagramHandle: z.string().optional(),
  socialMediaLinks: z.string().optional(),
  experience: z.string().optional(),
  message: z.string().min(10, "Message must be at least 10 characters"),
  turnstileToken: z.string().min(1, "Please complete the captcha")
})

const formStyles = `
  .form-input-glow {
    position: relative;
    transition: all 0.3s ease;
    background: white;
    border: 1px solid rgba(0, 0, 0, 0.1);
    -webkit-tap-highlight-color: transparent;
  }

  .form-input-glow:focus {
    border-color: rgba(0, 0, 0, 0.5);
    box-shadow: 0 0 25px rgba(0, 0, 0, 0.15),
                0 0 35px rgba(0, 0, 0, 0.1),
                inset 0 0 15px rgba(0, 0, 0, 0.05);
  }

  .error-message {
    color: #ef4444;
    font-size: 0.875rem;
    margin-top: 0.25rem;
    opacity: 0;
    transform: translateY(-10px);
    transition: all 0.3s ease;
  }

  .error-message.visible {
    opacity: 1;
    transform: translateY(0);
  }

  .turnstile {
    margin: 1rem auto;
    display: flex;
    justify-content: center;
  }
`

type FormData = z.infer<typeof formSchema>

export default function Contact() {
  const [formType, setFormType] = useState<"client" | "model">("client")
  const [isSubmitted, setIsSubmitted] = useState(false)
  const { 
    register, 
    handleSubmit, 
    formState: { errors }, 
    reset, 
    setValue,
    watch,
    trigger
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    mode: 'onChange' // Enable real-time validation
  })

  // Watch all fields for real-time validation
  const watchedFields = watch()

  // Trigger validation on field change
  useEffect(() => {
    if (Object.keys(errors).length > 0) {
      trigger()
    }
  }, [watchedFields, trigger])

  const onSubmit = async (data: FormData) => {
    try {
      // Here you would typically send the data to your server
      await new Promise(resolve => setTimeout(resolve, 1000)) // Simulated API call
      setIsSubmitted(true)
      reset()
      setTimeout(() => setIsSubmitted(false), 3000)
    } catch (error) {
      console.error('Error submitting form:', error)
    }
  }

  // Helper function to normalize URL
  const normalizeUrl = (url: string) => {
    if (!url) return url
    if (!url.match(/^https?:\/\//i)) {
      return `https://${url}`
    }
    return url
  }

  return (
    <section id="contact-section" className="relative bg-white py-24 z-[1]">
      <style>{formStyles}</style>
      <div className="container relative px-4 md:px-6 z-[2]">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mx-auto max-w-2xl text-center"
        >
          <h2 className="mb-2 text-3xl font-bold tracking-tighter text-black sm:text-4xl md:text-5xl">Get in Touch</h2>
          <p className="mb-8 text-gray-600">Whether you're a client looking to collaborate or talent seeking representation.</p>
        </motion.div>

        <div className="mx-auto max-w-md relative">
          <div className="bg-white rounded-lg p-8 shadow-lg relative">
            <AnimatePresence>
              {isSubmitted && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-95 z-10"
                >
                  <div className="text-center">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", damping: 10 }}
                      className="mb-4 inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100"
                    >
                      <Check className="w-8 h-8 text-green-600" />
                    </motion.div>
                    <h3 className="text-xl font-semibold mb-2">Thank You!</h3>
                    <p className="text-gray-600">We'll be in touch soon.</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <RadioGroup
              defaultValue="client"
              onValueChange={(value) => setFormType(value as "client" | "model")}
              className="mb-8 flex justify-center gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem 
                  value="client" 
                  id="client"
                  className="radio-glow border-black/20 text-black" 
                />
                <Label htmlFor="client" className="text-black">I'm a Client</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem 
                  value="model" 
                  id="model"
                  className="radio-glow border-black/20 text-black" 
                />
                <Label htmlFor="model" className="text-black">I'm Talent</Label>
              </div>
            </RadioGroup>

            <motion.form
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
              onSubmit={handleSubmit(onSubmit)}
            >
              <motion.div
                initial={{ x: -10, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.1 }}
              >
                <Input
                  {...register('name')}
                  placeholder="Name"
                  className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                />
                <div className={`error-message ${errors.name ? 'visible' : ''}`}>
                  {errors.name?.message}
                </div>
              </motion.div>

              <motion.div
                initial={{ x: -10, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                <Input
                  {...register('email')}
                  type="email"
                  placeholder="Email"
                  className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                />
                <div className={`error-message ${errors.email ? 'visible' : ''}`}>
                  {errors.email?.message}
                </div>
              </motion.div>

              {formType === "client" ? (
                <>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                  >
                    <Input
                      {...register('companyName')}
                      placeholder="Company Name"
                      className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                  </motion.div>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                  >
                    <Input
                      {...register('website', {
                        setValueAs: normalizeUrl
                      })}
                      placeholder="Website"
                      className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                    <div className={`error-message ${errors.website ? 'visible' : ''}`}>
                      {errors.website?.message}
                    </div>
                  </motion.div>
                </>
              ) : (
                <>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                  >
                    <Input
                      {...register('instagramHandle')}
                      placeholder="Instagram Handle"
                      className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                  </motion.div>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                  >
                    <Input
                      {...register('socialMediaLinks')}
                      placeholder="Other Social Media Links"
                      className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                  </motion.div>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.5 }}
                  >
                    <Textarea
                      {...register('experience')}
                      placeholder="Tell us about yourself and your experience"
                      className="form-input-glow min-h-[100px] rounded-lg p-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                  </motion.div>
                </>
              )}

              <motion.div
                initial={{ x: -10, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                <Textarea
                  {...register('message')}
                  placeholder="Message"
                  className="form-input-glow min-h-[100px] rounded-lg p-4 text-black placeholder:text-gray-500 focus:outline-none"
                />
                <div className={`error-message ${errors.message ? 'visible' : ''}`}>
                  {errors.message?.message}
                </div>
              </motion.div>

              <div className="turnstile">
                <Turnstile
                  siteKey="1x00000000000000000000AA"
                  onSuccess={(token) => setValue('turnstileToken', token)}
                  options={{
                    theme: 'light',
                    appearance: 'minimal'
                  }}
                />
              </div>
              
              <motion.div
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7 }}
              >
                <Button 
                  type="submit"
                  className="h-12 w-full rounded-lg bg-black text-white transition-all hover:bg-black/90"
                >
                  Submit
                </Button>
              </motion.div>
            </motion.form>
          </div>
        </div>
      </div>
    </section>
  )
}

