'use client'

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

const formStyles = `
  .form-input-glow {
    position: relative;
    transition: all 0.3s ease;
    background: white;
    border: 1px solid rgba(0, 0, 0, 0.1);
    -webkit-tap-highlight-color: transparent;
  }

  .form-input-glow:focus {
    border-color: rgba(0, 0, 0, 0.5);
    box-shadow: 0 0 25px rgba(0, 0, 0, 0.15),
                0 0 35px rgba(0, 0, 0, 0.1),
                inset 0 0 15px rgba(0, 0, 0, 0.05);
  }
`

export default function Contact() {
  const [formType, setFormType] = useState<"client" | "model">("client")

  return (
    <section id="contact-section" className="relative bg-white py-24" style={{ zIndex: 1 }}>
      <style>{formStyles}</style>
      <div className="container relative px-4 md:px-6" style={{ zIndex: 2 }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mx-auto max-w-2xl text-center"
        >
          <h2 className="mb-2 text-3xl font-bold tracking-tighter text-black sm:text-4xl md:text-5xl">Get in Touch</h2>
          <p className="mb-8 text-gray-600">Whether you're a client looking to collaborate or talent seeking representation.</p>
        </motion.div>

        <div className="mx-auto max-w-md relative z-10">
          <div className="bg-white rounded-lg p-8 shadow-lg relative" style={{ zIndex: 3 }}>
            <RadioGroup
              defaultValue="client"
              onValueChange={(value) => setFormType(value as "client" | "model")}
              className="mb-8 flex justify-center gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem 
                  value="client" 
                  id="client"
                  className="radio-glow border-black/20 text-black" 
                />
                <Label htmlFor="client" className="text-black">I'm a Client</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem 
                  value="model" 
                  id="model"
                  className="radio-glow border-black/20 text-black" 
                />
                <Label htmlFor="model" className="text-black">I'm Talent</Label>
              </div>
            </RadioGroup>

            <motion.form
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
            >
              <motion.div
                initial={{ x: -10, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.1 }}
              >
                <Input
                  placeholder="Name"
                  className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                />
              </motion.div>
              <motion.div
                initial={{ x: -10, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                <Input
                  type="email"
                  placeholder="Email"
                  className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                />
              </motion.div>

              {formType === "client" ? (
                <>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                  >
                    <Input
                      placeholder="Company Name"
                      className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                  </motion.div>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                  >
                    <Input
                      placeholder="Website"
                      className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                  </motion.div>
                </>
              ) : (
                <>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                  >
                    <Input
                      placeholder="Instagram Handle"
                      className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                  </motion.div>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                  >
                    <Input
                      placeholder="Other Social Media Links"
                      className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                  </motion.div>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.5 }}
                  >
                    <Textarea
                      placeholder="Tell us about yourself and your experience"
                      className="form-input-glow min-h-[100px] rounded-lg p-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                  </motion.div>
                </>
              )}

              <motion.div
                initial={{ x: -10, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                <Textarea
                  placeholder="Message"
                  className="form-input-glow min-h-[100px] rounded-lg p-4 text-black placeholder:text-gray-500 focus:outline-none"
                />
              </motion.div>
              <motion.div
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7 }}
              >
                <Button 
                  className="h-12 w-full rounded-lg bg-black text-white transition-all hover:bg-black/90"
                >
                  Submit
                </Button>
              </motion.div>
            </motion.form>
          </div>
        </div>
      </div>
    </section>
  )
}

