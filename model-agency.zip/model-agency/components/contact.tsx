'use client'

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Check } from 'lucide-react'
import { useForm } from "react-hook-form"
import { z } from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { turnstile } from '@marsidev/react-turnstile'

// Form validation schema
const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email"),
  companyName: z.string().optional(),
  website: z.string().url("Please enter a valid URL").optional(),
  instagramHandle: z.string().optional(),
  socialMediaLinks: z.string().optional(),
  experience: z.string().optional(),
  message: z.string().min(10, "Message must be at least 10 characters"),
  turnstileToken: z.string().min(1, "Please complete the captcha")
})

const formStyles = `
  .form-input-glow {
    position: relative;
    transition: all 0.3s ease;
    background: white;
    border: 1px solid rgba(0, 0, 0, 0.1);
    -webkit-tap-highlight-color: transparent;
  }

  .form-input-glow:focus {
    border-color: rgba(0, 0, 0, 0.5);
    box-shadow: 0 0 25px rgba(0, 0, 0, 0.15),
                0 0 35px rgba(0, 0, 0, 0.1),
                inset 0 0 15px rgba(0, 0, 0, 0.05);
  }

  .error-message {
    color: #ef4444;
    font-size: 0.875rem;
    margin-top: 0.25rem;
  }
`

export default function Contact() {
  const [formType, setFormType] = useState<"client" | "model">("client")
  const [isSubmitted, setIsSubmitted] = useState(false)
  const { register, handleSubmit, formState: { errors }, reset, setValue } = useForm({
    resolver: zodResolver(formSchema)
  })

  // Turnstile setup
  turnstile.render({
    sitekey: 'your-turnstile-site-key',
    callback: function(token) {
      setValue('turnstileToken', token)
    },
  })

  const onSubmit = async (data: any) => {
    try {
      // Here you would typically send the data to your server
      await new Promise(resolve => setTimeout(resolve, 1000)) // Simulated API call
      setIsSubmitted(true)
      reset()
      setTimeout(() => setIsSubmitted(false), 3000)
    } catch (error) {
      console.error('Error submitting form:', error)
    }
  }

  return (
    <section id="contact-section" className="relative bg-white py-24" style={{ zIndex: 1 }}>
      <style>{formStyles}</style>
      <div className="container relative px-4 md:px-6" style={{ zIndex: 2 }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mx-auto max-w-2xl text-center"
        >
          <h2 className="mb-2 text-3xl font-bold tracking-tighter text-black sm:text-4xl md:text-5xl">Get in Touch</h2>
          <p className="mb-8 text-gray-600">Whether you're a client looking to collaborate or talent seeking representation.</p>
        </motion.div>

        <div className="mx-auto max-w-md relative">
          <div className="bg-white rounded-lg p-8 shadow-lg relative">
            <AnimatePresence>
              {isSubmitted && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-95 z-10"
                >
                  <div className="text-center">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", damping: 10 }}
                      className="mb-4 inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100"
                    >
                      <Check className="w-8 h-8 text-green-600" />
                    </motion.div>
                    <h3 className="text-xl font-semibold mb-2">Thank You!</h3>
                    <p className="text-gray-600">We'll be in touch soon.</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <RadioGroup
              defaultValue="client"
              onValueChange={(value) => setFormType(value as "client" | "model")}
              className="mb-8 flex justify-center gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem 
                  value="client" 
                  id="client"
                  className="radio-glow border-black/20 text-black" 
                />
                <Label htmlFor="client" className="text-black">I'm a Client</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem 
                  value="model" 
                  id="model"
                  className="radio-glow border-black/20 text-black" 
                />
                <Label htmlFor="model" className="text-black">I'm Talent</Label>
              </div>
            </RadioGroup>

            <motion.form
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
              onSubmit={handleSubmit(onSubmit)}
            >
              <motion.div
                initial={{ x: -10, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.1 }}
              >
                <Input
                  {...register('name')}
                  placeholder="Name"
                  className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                />
                {errors.name && (
                  <p className="error-message">{errors.name.message?.toString()}</p>
                )}
              </motion.div>

              <motion.div
                initial={{ x: -10, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                <Input
                  {...register('email')}
                  type="email"
                  placeholder="Email"
                  className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                />
                {errors.email && (
                  <p className="error-message">{errors.email.message?.toString()}</p>
                )}
              </motion.div>

              {formType === "client" ? (
                <>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                  >
                    <Input
                      {...register('companyName')}
                      placeholder="Company Name"
                      className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                  </motion.div>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                  >
                    <Input
                      {...register('website')}
                      placeholder="Website"
                      className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                    {errors.website && (
                      <p className="error-message">{errors.website.message?.toString()}</p>
                    )}
                  </motion.div>
                </>
              ) : (
                <>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.3 }}
                  >
                    <Input
                      {...register('instagramHandle')}
                      placeholder="Instagram Handle"
                      className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                  </motion.div>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                  >
                    <Input
                      {...register('socialMediaLinks')}
                      placeholder="Other Social Media Links"
                      className="form-input-glow h-12 rounded-lg px-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                  </motion.div>
                  <motion.div
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.5 }}
                  >
                    <Textarea
                      {...register('experience')}
                      placeholder="Tell us about yourself and your experience"
                      className="form-input-glow min-h-[100px] rounded-lg p-4 text-black placeholder:text-gray-500 focus:outline-none"
                    />
                  </motion.div>
                </>
              )}

              <motion.div
                initial={{ x: -10, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                <Textarea
                  {...register('message')}
                  placeholder="Message"
                  className="form-input-glow min-h-[100px] rounded-lg p-4 text-black placeholder:text-gray-500 focus:outline-none"
                />
                {errors.message && (
                  <p className="error-message">{errors.message.message?.toString()}</p>
                )}
              </motion.div>

              {/* Hidden turnstile token field */}
              <input type="hidden" {...register('turnstileToken')} />
              
              <motion.div
                initial={{ y: 10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7 }}
              >
                <Button 
                  type="submit"
                  className="h-12 w-full rounded-lg bg-black text-white transition-all hover:bg-black/90"
                >
                  Submit
                </Button>
              </motion.div>
            </motion.form>
          </div>
        </div>
      </div>
    </section>
  )
}

