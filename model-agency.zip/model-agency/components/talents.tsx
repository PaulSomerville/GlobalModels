'use client'

import { useRef, useEffect } from "react"
import { motion, useAnimation, useInView } from "framer-motion"
import Image from "next/image"

const talents = [
  { id: 1, image: "/placeholder.svg?height=450&width=300" },
  { id: 2, image: "/placeholder.svg?height=450&width=300" },
  { id: 3, image: "/placeholder.svg?height=450&width=300" },
  { id: 4, image: "/placeholder.svg?height=450&width=300" },
]

export default function Talents() {
  const containerRef = useRef<HTMLDivElement>(null)
  const isInView = useInView(containerRef, { once: false, amount: 0.2 })
  const controls = useAnimation()

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    }
  }, [isInView, controls])

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
      },
    },
  }

  return (
    <section ref={containerRef} className="relative overflow-hidden py-24 bg-gray-100">
      <div className="container px-4 md:px-6 mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={controls}
          className="mb-12 text-center text-3xl font-bold tracking-tighter sm:text-4xl"
        >
          Featured Talent
        </motion.h2>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={controls}
          className="flex overflow-x-auto gap-6 pb-8 no-scrollbar"
        >
          {[...talents, ...talents, ...talents].map((talent, index) => (
            <motion.div
              key={`${talent.id}-${index}`}
              variants={cardVariants}
              className="relative flex-none w-[300px] h-[450px] overflow-hidden rounded-lg shadow-lg"
            >
              <Image
                src={talent.image}
                alt="Model"
                fill
                className="object-cover"
                sizes="300px"
                priority={index < 4}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

