'use client'

import { useRef } from "react"
import { motion, useScroll, useTransform } from "framer-motion"
import Image from "next/image"

const talents = [
  {
    id: 1,
    image: "/placeholder.svg?height=450&width=300",
  },
  {
    id: 2,
    image: "/placeholder.svg?height=450&width=300",
  },
  {
    id: 3,
    image: "/placeholder.svg?height=450&width=300",
  },
  {
    id: 4,
    image: "/placeholder.svg?height=450&width=300",
  },
]

export default function Talents() {
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"],
  })

  const x = useTransform(scrollYProgress, [0, 1], ["0%", "-50%"])

  return (
    <section ref={containerRef} className="relative overflow-hidden py-24" style={{ zIndex: 1 }}>
      <div className="container px-4 md:px-6">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 text-center text-3xl font-bold tracking-tighter sm:text-4xl"
        >
          Featured Talent
        </motion.h2>
      </div>
      <motion.div
        style={{ x }}
        className="flex w-[200%] gap-4 px-4"
      >
        {[...talents, ...talents].map((talent, index) => (
          <div
            key={`${talent.id}-${index}`}
            className="relative aspect-[2/3] w-[300px] flex-none overflow-hidden"
          >
            <Image
              src={talent.image}
              alt="Featured Talent"
              fill
              className="object-cover"
              sizes="300px"
              priority={index < 4}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          </div>
        ))}
      </motion.div>
    </section>
  )
}

