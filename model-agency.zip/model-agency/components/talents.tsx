import { useState } from 'react';
import { motion } from 'framer-motion';

function MyComponent() {
  const [x, setX] = useState(0);
  const [isScrolling, setIsScrolling] = useState(false);

  return (
    <div>
      <motion.div
        style={{ x: isScrolling ? undefined : x }}
        className="flex w-[200%] gap-4 px-4 overflow-x-auto touch-pan-x scrollbar-hide scroll-smooth"
        onTouchStart={() => setIsScrolling(true)}
        onTouchEnd={() => setIsScrolling(false)}
        onMouseDown={() => setIsScrolling(true)}
        onMouseUp={() => setIsScrolling(false)}
        onMouseLeave={() => setIsScrolling(false)}
      >
        {/* Your scrollable content here */}
        <div>Item 1</div>
        <div>Item 2</div>
        <div>Item 3</div>
        <div>Item 4</div>
        <div>Item 5</div>
      </motion.div>
    </div>
  );
}

export default MyComponent;

