'use client'

import { useRef } from "react"
import { motion, useScroll, useTransform } from "framer-motion"
import Image from "next/image"

const talents = [
  {
    id: 1,
    image: "https://res.cloudinary.com/djvd9w1vv/image/upload/v1733009225/10_scmnlr.jpg",
  },
  {
    id: 2,
    image: "https://res.cloudinary.com/djvd9w1vv/image/upload/v1733006225/E2_1_xiyncp.webp",
  },
  {
    id: 3,
    image: "https://res.cloudinary.com/djvd9w1vv/image/upload/v1733009218/2_donwrh.jpg",
  },
  {
    id: 4,
    image: "https://res.cloudinary.com/djvd9w1vv/image/upload/v1733009218/1_chxadm.jpg",
  },
  {
    id: 5,
    image: "https://res.cloudinary.com/djvd9w1vv/image/upload/v1733006224/E1_1_sv7rnz.webp",
  },
  {
    id: 6,
    image: "https://res.cloudinary.com/djvd9w1vv/image/upload/v1733009218/3_wg2efw.jpg",
  },
  {
    id: 7,
    image: "https://res.cloudinary.com/djvd9w1vv/image/upload/v1733006236/E10_ezrzfk.webp",
  },
  {
    id: 8,
    image: "https://res.cloudinary.com/djvd9w1vv/image/upload/v1733009220/4_fsi38i.jpg",
  },
  {
    id: 9,
    image: "https://res.cloudinary.com/djvd9w1vv/image/upload/v1733009224/8_xjfrju.jpg",
  },
  {
    id: 10,
    image: "https://res.cloudinary.com/djvd9w1vv/image/upload/v1733009223/7_bcvnwx.jpg",
  },
  {
    id: 11,
    image: "https://res.cloudinary.com/djvd9w1vv/image/upload/v1733009221/5_rvol1d.jpg",
  },
  {
    id: 12,
    image: "https://res.cloudinary.com/djvd9w1vv/image/upload/v1733009225/9_ilerif.jpg",
  },
]

export default function Talents() {
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"],
  })

  const x = useTransform(scrollYProgress, [0, 1], ["0%", "-50%"])

  return (
    <section ref={containerRef} className="relative overflow-hidden py-24" style={{ zIndex: 1 }}>
      <div className="container px-4 md:px-6">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 text-center text-3xl font-bold tracking-tighter sm:text-4xl"
        >
          Featured Talent
        </motion.h2>
      </div>
      <motion.div
        style={{ x }}
        className="flex w-[200%] gap-4 px-4"
      >
        {[...talents, ...talents].map((talent, index) => (
          <div
            key={`${talent.id}-${index}`}
            className="relative aspect-[2/3] w-[300px] flex-none overflow-hidden rounded-lg"
          >
            <Image
              src={talent.image}
              alt="Featured Talent"
              fill
              className="object-cover"
              sizes="300px"
              priority={index < 4}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          </div>
        ))}
      </motion.div>
    </section>
  )
}

