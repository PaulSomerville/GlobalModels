'use client'

import {
  motion,
  useScroll,
  useTransform,
} from "framer-motion"
import { useRef } from "react"

const imagePositions = [
  { x: -20, y: -15, scale: 0.9, blur: '8px' },
  { x: 20, y: 10, scale: 0.8, blur: '12px' },
  { x: -15, y: 20, scale: 0.7, blur: '16px' },
  { x: 25, y: -10, scale: 0.6, blur: '20px' },
]

export default function About() {
  const containerRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLDivElement>(null)

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  })

  const opacity = useTransform(scrollYProgress, [0, 0.5], [0, 1])
  const scale = useTransform(scrollYProgress, [0, 0.5], [0.8, 1])
  const y = useTransform(scrollYProgress, [0, 0.5, 1], [100, 0, -100])

  return (
    <section 
      ref={containerRef}
      className="relative min-h-[60vh] overflow-hidden bg-white py-24"
    >
      {/* Background images with depth of field */}
      <div className="absolute inset-0 overflow-hidden">
        {imagePositions.map((pos, index) => (
          <motion.div
            key={index}
            className="absolute left-1/2 top-1/2 h-64 w-64"
            style={{
              x: useTransform(scrollYProgress, 
                [0, 1], 
                [0, pos.x * 20]
              ),
              y: useTransform(scrollYProgress, 
                [0, 1], 
                [0, pos.y * 20]
              ),
              scale: useTransform(scrollYProgress,
                [0, 1],
                [1, pos.scale]
              ),
              filter: `blur(${pos.blur})`,
              opacity: useTransform(scrollYProgress,
                [0, 0.5, 1],
                [0, 0.15, 0]
              ),
            }}
          >
            <div 
              className="h-full w-full rounded-2xl bg-black/30"
              style={{
                transform: 'translate(-50%, -50%)',
              }}
            />
          </motion.div>
        ))}
      </div>

      {/* Animated background elements */}
      <div className="absolute inset-0">
        <motion.div
          style={{ opacity }}
          className="absolute left-1/4 top-1/4 h-64 w-64 rounded-full bg-black/[0.03] blur-3xl"
        />
        <motion.div
          style={{ opacity }}
          className="absolute right-1/4 top-2/3 h-64 w-64 rounded-full bg-black/[0.03] blur-3xl"
        />
      </div>

      {/* Main content */}
      <div className="relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            ref={textRef}
            style={{ 
              opacity,
              scale,
              y
            }}
            className="relative mx-auto max-w-3xl text-center"
          >
            {/* Decorative line */}
            <motion.div
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
              className="mx-auto mb-8 h-px w-12 bg-black"
            />

            {/* Text content */}
            <div className="relative">
              <motion.p
                className="text-balance text-xl font-bold leading-relaxed text-black md:text-2xl lg:text-3xl"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                Global Models provides campaigns, models, and influencers to businesses all over the world.
              </motion.p>
            </div>

            {/* Bottom line */}
            <motion.div
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
              className="mx-auto mt-8 h-px w-12 bg-black"
            />
          </motion.div>
        </div>
      </div>

      {/* Scroll-based floating shapes */}
      <motion.div
        style={{ y: useTransform(scrollYProgress, [0, 1], [0, -50]) }}
        className="absolute bottom-0 left-0 right-0 z-0"
      >
        <div className="mx-auto grid max-w-7xl grid-cols-3 gap-8 px-4 sm:px-6 lg:px-8">
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: i * 0.1 }}
              className="aspect-square rounded-2xl bg-black/[0.02]"
            />
          ))}
        </div>
      </motion.div>
    </section>
  )
}

