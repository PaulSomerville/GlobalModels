'use client'

import {
  motion,
  useScroll,
  useTransform,
} from "framer-motion"
import { useRef } from "react"

const imagePositions = [
  { 
    x: -10,
    y: -7,
    scale: 0.95,
    blur: '4px',
    size: 48,
  },
  { 
    x: 10,
    y: 5,
    scale: 0.9,
    blur: '6px',
    size: 40,
  },
  { 
    x: -7,
    y: 10,
    scale: 0.85,
    blur: '8px',
    size: 36,
  },
  { 
    x: 12,
    y: -5,
    scale: 0.8,
    blur: '10px',
    size: 32,
  },
]

export default function About() {
  const containerRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLDivElement>(null)

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  })

  const opacity = useTransform(scrollYProgress, [0, 0.5], [0, 1])
  const scale = useTransform(scrollYProgress, [0, 0.5], [0.9, 1])
  const y = useTransform(scrollYProgress, [0, 0.5, 1], [50, 0, -50])

  return (
    <section 
      ref={containerRef}
      className="relative min-h-[40vh] overflow-hidden bg-white pb-12 pt-24"
    >
      {/* Background images with pointer-events-none to prevent interaction blocking */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {imagePositions.map((pos, index) => (
          <motion.div
            key={index}
            className="absolute left-1/2 top-1/2 pointer-events-none"
            style={{
              width: `${pos.size}px`,
              height: `${pos.size}px`,
              x: useTransform(scrollYProgress, 
                [0, 1], 
                [0, pos.x * 10]
              ),
              y: useTransform(scrollYProgress, 
                [0, 1], 
                [0, pos.y * 10]
              ),
              scale: useTransform(scrollYProgress,
                [0, 1],
                [1, pos.scale]
              ),
              filter: `blur(${pos.blur})`,
              opacity: useTransform(scrollYProgress,
                [0, 0.5, 1],
                [0, 0.1, 0]
              ),
            }}
          >
            <div 
              className="h-full w-full rounded-2xl bg-black/20 pointer-events-none"
              style={{
                transform: 'translate(-50%, -50%)',
              }}
            />
          </motion.div>
        ))}
      </div>

      {/* Animated background blur elements with pointer-events-none */}
      <div className="absolute inset-0 pointer-events-none">
        <motion.div
          style={{ opacity }}
          className="absolute left-1/4 top-1/4 h-32 w-32 rounded-full bg-black/[0.02] blur-2xl pointer-events-none"
        />
        <motion.div
          style={{ opacity }}
          className="absolute right-1/4 top-2/3 h-32 w-32 rounded-full bg-black/[0.02] blur-2xl pointer-events-none"
        />
      </div>

      {/* Main content container */}
      <div className="relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            ref={textRef}
            style={{ 
              opacity,
              scale,
              y
            }}
            className="relative mx-auto max-w-3xl text-center"
          >
            <div className="relative">
              <motion.p
                className="text-balance text-xl font-bold leading-relaxed text-black md:text-2xl lg:text-3xl"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                Global Models provides campaigns, models, and influencers to businesses all over the world.
              </motion.p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

