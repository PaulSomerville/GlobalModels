'use client'

import {
  motion,
  useScroll,
  useTransform,
  useSpring,
  type MotionValue
} from "framer-motion"

const achievements = [
  { number: "15+", label: "Years" },
  { number: "500+", label: "Talents" },
  { number: "50+", label: "Countries" },
]

export default function About() {
  return (
    <section className="relative overflow-hidden bg-white py-24">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: 'radial-gradient(circle at 2px 2px, black 1px, transparent 0)',
            backgroundSize: '40px 40px'
          }}
        />
      </div>

      {/* Main Content */}
      <div className="relative z-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="mb-20 text-center"
          >
            <h2 className="text-5xl font-bold tracking-tight sm:text-7xl">
              Global Excellence
            </h2>
            <motion.div
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="mx-auto mt-8 h-px w-24 bg-black"
            />
          </motion.div>

          {/* Achievement Cards */}
          <div className="grid gap-8 md:grid-cols-3">
            {achievements.map((achievement, index) => (
              <motion.div
                key={achievement.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
                className="group relative overflow-hidden rounded-2xl bg-white p-8 shadow-lg"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-black/[0.02] to-transparent" />
                <div className="relative z-10">
                  <motion.div
                    initial={{ scale: 0.5 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.2 + index * 0.1 }}
                    className="mb-4 text-6xl font-bold"
                  >
                    {achievement.number}
                  </motion.div>
                  <motion.div
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.3 + index * 0.1 }}
                    className="text-xl text-gray-600"
                  >
                    {achievement.label}
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Bottom Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="mt-20 text-center"
          >
            <div className="mx-auto max-w-2xl rounded-2xl bg-gray-50 p-12">
              <h3 className="mb-4 text-3xl font-bold">Setting New Standards</h3>
              <p className="text-gray-600">
                Leading the future of talent management and creative direction
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

