'use client'

import { useRef } from "react"
import { motion, useScroll, useTransform } from "framer-motion"
import Image from "next/image"

export default function About() {
  const ref = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  })

  const y = useTransform(scrollYProgress, [0, 1], [100, -100])

  return (
    <section ref={ref} className="relative overflow-hidden bg-white py-24 md:py-32">
      <div className="container relative px-4 md:px-6">
        <div className="grid gap-12 md:grid-cols-2 md:gap-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="flex flex-col justify-center space-y-4"
          >
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="space-y-2"
            >
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">About Us</h2>
              <p className="max-w-[600px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Established in the heart of the fashion industry, GLOBAL MODELS has been at the forefront of talent management
                and creative direction.
              </p>
            </motion.div>
            <div className="space-y-2">
              <motion.p
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4 }}
                className="text-sm text-gray-500 md:text-base"
              >
                Our vision extends beyond traditional modeling, embracing the digital age with innovative campaigns and
                influential partnerships.
              </motion.p>
              <motion.p
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.6 }}
                className="text-sm text-gray-500 md:text-base"
              >
                We pride ourselves on discovering and nurturing exceptional talent, creating meaningful connections between
                brands and audiences worldwide.
              </motion.p>
            </div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.8 }}
              className="flex flex-col gap-2 min-[400px]:flex-row"
            >
              <div className="flex flex-col">
                <span className="text-4xl font-bold">15+</span>
                <span className="text-sm text-gray-500">Years Experience</span>
              </div>
              <div className="flex flex-col">
                <span className="text-4xl font-bold">500+</span>
                <span className="text-sm text-gray-500">Global Talents</span>
              </div>
              <div className="flex flex-col">
                <span className="text-4xl font-bold">50+</span>
                <span className="text-sm text-gray-500">Countries</span>
              </div>
            </motion.div>
          </motion.div>
          <div className="relative h-[500px] md:h-auto">
            <motion.div
              style={{ y }}
              className="relative h-full w-full"
            >
              <Image
                src="/placeholder.svg?height=800&width=600"
                alt="About GLOBAL MODELS"
                fill
                className="object-cover"
                priority
              />
              <div className="absolute inset-0 bg-black/10" />
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}

