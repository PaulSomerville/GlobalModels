'use client'

import { useRef, useEffect, useState } from "react"
import { motion, useScroll, useTransform, useSpring, useInView } from "framer-motion"
import Image from "next/image"

// Utility function for splitting text
const SplitText = ({ children }: { children: string }) => {
  return (
    <span className="inline-block overflow-hidden">
      {children.split("").map((char, i) => (
        <motion.span
          key={i}
          className="inline-block"
          initial={{ y: 50 }}
          whileInView={{ y: 0 }}
          viewport={{ once: true }}
          transition={{
            duration: 0.5,
            delay: i * 0.02,
            ease: [0.33, 1, 0.68, 1]
          }}
        >
          {char === " " ? "\u00A0" : char}
        </motion.span>
      ))}
    </span>
  )
}

const Counter = ({ end, duration = 2 }: { end: number; duration?: number }) => {
  const [count, setCount] = useState(0)
  const ref = useRef(null)
  const isInView = useInView(ref)

  useEffect(() => {
    if (isInView) {
      let startTime: number
      let animationFrame: number

      const animate = (timestamp: number) => {
        if (!startTime) startTime = timestamp
        const progress = (timestamp - startTime) / (duration * 1000)

        if (progress < 1) {
          setCount(Math.min(Math.floor(end * progress), end))
          animationFrame = requestAnimationFrame(animate)
        } else {
          setCount(end)
        }
      }

      animationFrame = requestAnimationFrame(animate)
      return () => cancelAnimationFrame(animationFrame)
    }
  }, [end, duration, isInView])

  return <span ref={ref}>{count}</span>
}

export default function About() {
  const ref = useRef<HTMLDivElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const isInView = useInView(ref, { once: true })
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  })

  const y = useSpring(
    useTransform(scrollYProgress, [0, 1], [100, -100]),
    { stiffness: 100, damping: 30 }
  )

  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 1.1])
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0.3, 1, 1, 0.3])

  const backgroundY = useTransform(scrollYProgress, [0, 1], [0, -100])

  return (
    <section 
      ref={ref} 
      className="relative overflow-hidden bg-white py-24 md:py-32"
    >
      {/* Main title */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="container mb-16 px-4 md:px-6"
      >
        <h2 className="text-center text-5xl font-bold tracking-tight sm:text-7xl">
          <SplitText>About Us</SplitText>
        </h2>
      </motion.div>

      {/* Animated background elements */}
      <motion.div
        style={{ y: backgroundY }}
        className="pointer-events-none absolute inset-0 overflow-hidden"
      >
        <div className="absolute -left-4 top-1/4 h-64 w-64 rounded-full bg-gray-100 blur-3xl" />
        <div className="absolute -right-4 top-3/4 h-64 w-64 rounded-full bg-gray-50 blur-3xl" />
      </motion.div>

      <div className="container relative px-4 md:px-6">
        <div className="grid gap-12 md:grid-cols-2 md:gap-16">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="flex flex-col justify-center space-y-8"
          >
            <div className="space-y-6">
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="max-w-[600px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed"
              >
                Established in the heart of the fashion industry, GLOBAL MODELS has been at the forefront of talent management
                and creative direction.
              </motion.p>
            </div>

            <div className="space-y-6">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4 }}
                className="group relative overflow-hidden rounded-xl border border-black/5 bg-white p-6 shadow-lg transition-all duration-500 hover:shadow-xl"
              >
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-black/[0.03] to-transparent"
                  initial={{ x: '-100%' }}
                  whileHover={{ x: '100%' }}
                  transition={{ duration: 1.5 }}
                />
                <p className="relative text-sm text-gray-500 md:text-base">
                  Our vision extends beyond traditional modeling, embracing the digital age with innovative campaigns and
                  influential partnerships.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.6 }}
                className="group relative overflow-hidden rounded-xl border border-black/5 bg-white p-6 shadow-lg transition-all duration-500 hover:shadow-xl"
              >
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-black/[0.03] to-transparent"
                  initial={{ x: '-100%' }}
                  whileHover={{ x: '100%' }}
                  transition={{ duration: 1.5 }}
                />
                <p className="relative text-sm text-gray-500 md:text-base">
                  We pride ourselves on discovering and nurturing exceptional talent, creating meaningful connections between
                  brands and audiences worldwide.
                </p>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.8 }}
              className="grid grid-cols-3 gap-8"
            >
              <motion.div
                whileHover={{ y: -5 }}
                className="flex flex-col items-center space-y-2 text-center"
              >
                <span className="text-4xl font-bold tabular-nums">
                  <Counter end={15} />+
                </span>
                <span className="text-sm text-gray-500">Years Experience</span>
              </motion.div>
              <motion.div
                whileHover={{ y: -5 }}
                className="flex flex-col items-center space-y-2 text-center"
              >
                <span className="text-4xl font-bold tabular-nums">
                  <Counter end={500} duration={2.5} />+
                </span>
                <span className="text-sm text-gray-500">Global Talents</span>
              </motion.div>
              <motion.div
                whileHover={{ y: -5 }}
                className="flex flex-col items-center space-y-2 text-center"
              >
                <span className="text-4xl font-bold tabular-nums">
                  <Counter end={50} />+
                </span>
                <span className="text-sm text-gray-500">Countries</span>
              </motion.div>
            </motion.div>
          </motion.div>

          <div className="relative h-[600px] md:h-auto">
            <motion.div
              style={{ 
                y,
                scale,
                opacity
              }}
              className="relative h-full w-full overflow-hidden rounded-2xl"
            >
              <Image
                src="/placeholder.svg?height=800&width=600"
                alt="About GLOBAL MODELS"
                fill
                className="object-cover"
                priority
              />
              <motion.div 
                className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/20"
                style={{
                  opacity: useTransform(scrollYProgress, [0, 0.5], [0.2, 0.4])
                }}
              />
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}

