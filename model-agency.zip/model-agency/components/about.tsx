'use client'

import {
  motion,
  useScroll,
  useTransform,
  type MotionValue
} from "framer-motion"

const images = [
  { id: 1, depth: 0.8 },
  { id: 2, depth: 0.6 },
  { id: 3, depth: 0.4 },
  { id: 4, depth: 0.2 },
]

export default function About() {
  const { scrollYProgress } = useScroll()

  return (
    <section className="relative min-h-[80vh] overflow-hidden bg-white py-24">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: 'radial-gradient(circle at 2px 2px, black 1px, transparent 0)',
            backgroundSize: '40px 40px'
          }}
        />
      </div>

      {/* 3D Image Collage */}
      <div 
        className="absolute inset-0"
        style={{
          perspective: '1000px',
          perspectiveOrigin: 'right',
          transform: 'rotate(-10deg)'
        }}
      >
        {images.map((image) => (
          <motion.div
            key={image.id}
            className="absolute left-1/2 top-1/2"
            style={{
              width: '300px',
              height: '400px',
              x: useTransform(
                scrollYProgress,
                [0, 1],
                [image.depth * 100, image.depth * -100]
              ),
              y: useTransform(
                scrollYProgress,
                [0, 1],
                [image.depth * 50, image.depth * -50]
              ),
              z: useTransform(
                scrollYProgress,
                [0, 1],
                [image.depth * 200, image.depth * -200]
              ),
              rotateY: '-30deg',
              translateX: `-${50 + image.depth * 20}%`,
              translateY: '-50%',
            }}
          >
            <div 
              className="h-full w-full overflow-hidden rounded-2xl"
              style={{
                background: 'rgba(0, 0, 0, 0.7)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)'
              }}
            >
              <div 
                className="h-full w-full"
                style={{
                  background: `url('/placeholder.svg?height=800&width=600') center/cover`,
                  opacity: 0.6,
                  mixBlendMode: 'overlay'
                }}
              />
            </div>
          </motion.div>
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative mx-auto max-w-2xl text-center"
          >
            <p className="text-lg font-light leading-relaxed text-gray-600 md:text-xl lg:text-2xl">
              Global Models provides campaigns, models, and influencers to businesses all over the world.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Gradient Overlay */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-white via-transparent to-white" />
    </section>
  )
}

