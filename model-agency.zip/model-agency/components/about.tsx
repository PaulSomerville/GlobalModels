'use client'

import { useRef } from "react"
import { motion, useScroll, useTransform, useSpring } from "framer-motion"
import Image from "next/image"

const achievements = [
  { number: "15+", label: "Years" },
  { number: "500+", label: "Talents" },
  { number: "50+", label: "Countries" },
]

export default function About() {
  const containerRef = useRef<HTMLDivElement>(null)
  const imageRef = useRef<HTMLDivElement>(null)
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"],
  })

  const y = useSpring(
    useTransform(scrollYProgress, [0, 1], [100, -100]),
    { stiffness: 100, damping: 30 }
  )

  const scale = useSpring(
    useTransform(scrollYProgress, [0, 0.5], [1, 1.2]),
    { stiffness: 100, damping: 30 }
  )

  const opacity = useTransform(
    scrollYProgress,
    [0, 0.2, 0.8, 1],
    [0.3, 1, 1, 0.3]
  )

  const textY = useTransform(scrollYProgress, [0, 1], [0, -50])

  return (
    <section 
      ref={containerRef}
      className="relative min-h-screen overflow-hidden bg-white"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, black 1px, transparent 0)',
          backgroundSize: '40px 40px'
        }} />
      </div>

      {/* Main Content */}
      <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-8">
          {/* Left Column - Text Content */}
          <motion.div
            style={{ y: textY }}
            className="flex flex-col justify-center"
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <motion.div
                initial={{ scaleX: 0 }}
                whileInView={{ scaleX: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="absolute -left-4 top-0 h-full w-1 origin-top bg-black"
              />
              <h2 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
                Global Excellence
              </h2>
              <p className="mt-4 max-w-3xl text-lg text-gray-600">
                Setting the standard in talent management and creative direction worldwide.
              </p>
            </motion.div>

            {/* Achievement Grid */}
            <div className="mt-16 grid grid-cols-3 gap-8">
              {achievements.map((achievement, index) => (
                <motion.div
                  key={achievement.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="relative"
                >
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    className="group relative overflow-hidden rounded-xl border border-black/5 bg-white p-4 shadow-lg transition-all duration-300 hover:shadow-xl"
                  >
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-black/[0.03] to-transparent"
                      initial={{ x: '-100%' }}
                      whileHover={{ x: '100%' }}
                      transition={{ duration: 1.5 }}
                    />
                    <div className="relative z-10">
                      <p className="text-3xl font-bold">{achievement.number}</p>
                      <p className="text-sm text-gray-600">{achievement.label}</p>
                    </div>
                  </motion.div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right Column - Image */}
          <div ref={imageRef} className="relative h-[600px] lg:h-auto">
            <motion.div
              style={{ 
                scale,
                opacity,
                y 
              }}
              className="relative h-full w-full"
            >
              <div className="absolute -right-4 -top-4 h-full w-full rounded-2xl border border-black/10 bg-black/5" />
              <div className="absolute -left-2 -top-2 h-full w-full rounded-2xl border border-black/10 bg-black/5" />
              <div className="relative h-full w-full overflow-hidden rounded-2xl border border-black/10">
                <Image
                  src="/placeholder.svg?height=800&width=600"
                  alt="About GLOBAL MODELS"
                  fill
                  className="object-cover"
                  priority
                />
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}

