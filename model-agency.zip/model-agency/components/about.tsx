'use client'

import { useRef, useEffect } from "react"
import { motion, useScroll, useTransform, useSpring, useInView } from "framer-motion"
import Image from "next/image"

const achievements = [
  { number: "15+", label: "Years" },
  { number: "500+", label: "Talents" },
  { number: "50+", label: "Countries" },
]

export default function About() {
  const containerRef = useRef<HTMLDivElement>(null)
  const horizontalRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLDivElement>(null)
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  })

  const springConfig = { stiffness: 100, damping: 30, bounce: 0 }
  
  const y = useSpring(
    useTransform(scrollYProgress, [0, 1], [0, -50]),
    springConfig
  )

  const scale = useSpring(
    useTransform(scrollYProgress, [0, 0.5], [1, 1.2]),
    springConfig
  )

  const textOpacity = useTransform(
    scrollYProgress,
    [0, 0.2, 0.8, 1],
    [0, 1, 1, 0]
  )

  const textX = useSpring(
    useTransform(scrollYProgress, [0, 1], [0, -100]),
    springConfig
  )

  // Horizontal scroll effect
  useEffect(() => {
    const element = horizontalRef.current
    if (element) {
      const onScroll = () => {
        const scrolled = window.scrollY - (element.offsetTop - window.innerHeight)
        const total = element.scrollWidth - element.clientWidth
        const percentage = Math.min(Math.max(scrolled / total, 0), 1)
        element.scrollLeft = percentage * total
      }
      window.addEventListener('scroll', onScroll)
      return () => window.removeEventListener('scroll', onScroll)
    }
  }, [])

  return (
    <section 
      ref={containerRef}
      className="relative min-h-[150vh] overflow-hidden bg-white pb-12"
    >
      {/* Fixed Background Pattern */}
      <div className="fixed inset-0 z-0">
        <div 
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage: 'radial-gradient(circle at 2px 2px, black 1px, transparent 0)',
            backgroundSize: '40px 40px'
          }}
        />
      </div>

      {/* Main Content */}
      <div className="relative z-10">
        {/* Intro Text */}
        <motion.div
          ref={textRef}
          style={{ opacity: textOpacity, x: textX }}
          className="sticky top-0 flex h-screen items-center justify-center"
        >
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center text-5xl font-bold tracking-tight sm:text-7xl"
            >
              Global Excellence
            </motion.h2>
          </div>
        </motion.div>

        {/* Horizontal Scroll Section */}
        <div 
          ref={horizontalRef}
          className="no-scrollbar sticky top-0 flex h-screen items-center overflow-x-hidden"
        >
          <div className="flex gap-8 px-[50vw]">
            {achievements.map((achievement, index) => (
              <motion.div
                key={achievement.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="relative flex h-[50vh] w-[40vw] flex-none items-center justify-center overflow-hidden rounded-2xl bg-white"
                style={{
                  perspective: "1000px"
                }}
              >
                <motion.div
                  whileHover={{ scale: 1.05, rotateY: 5 }}
                  className="group relative flex h-full w-full items-center justify-center"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-black/[0.02] to-transparent" />
                  <div className="relative z-10 text-center">
                    <motion.span 
                      className="block text-6xl font-bold md:text-8xl"
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.2 }}
                    >
                      {achievement.number}
                    </motion.span>
                    <motion.span 
                      className="mt-2 block text-xl text-gray-600 md:text-2xl"
                      initial={{ opacity: 0 }}
                      whileInView={{ opacity: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.3 }}
                    >
                      {achievement.label}
                    </motion.span>
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Image Section */}
        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            style={{ scale }}
            className="relative mx-auto aspect-[16/9] max-w-4xl overflow-hidden rounded-2xl"
          >
            <Image
              src="/placeholder.svg?height=1080&width=1920"
              alt="GLOBAL MODELS"
              fill
              className="object-cover"
              priority
            />
            <motion.div 
              className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/20"
              style={{
                opacity: useTransform(scrollYProgress, [0, 0.5], [0.2, 0.4])
              }}
            />
          </motion.div>
        </div>
      </div>

      {/* Custom scroll progress indicator */}
      <motion.div 
        className="fixed bottom-8 left-1/2 h-[2px] w-[100px] -translate-x-1/2 bg-black/20"
      >
        <motion.div 
          className="h-full bg-black"
          style={{ 
            scaleX: scrollYProgress,
            transformOrigin: "0%"
          }}
        />
      </motion.div>
    </section>
  )
}

