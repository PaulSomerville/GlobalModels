'use client'

import {
  motion,
  useScroll,
  useTransform,
} from "framer-motion"
import { useRef } from "react"

// Define positions for background floating images
// Each object represents an image's position and visual properties
const imagePositions = [
  { 
    x: -20,      // Moves left from center
    y: -15,      // Moves up from center
    scale: 0.9,  // Slightly smaller than original
    blur: '8px', // Minimal blur for closest layer
    // This will be the most visible and closest to viewer
  },
  { 
    x: 20,       // Moves right from center
    y: 10,       // Moves down from center
    scale: 0.8,  // Smaller scale for middle distance
    blur: '12px', // More blur for middle layer
    // Creates middle layer depth
  },
  { 
    x: -15,      // Moves left from center
    y: 20,       // Moves down from center
    scale: 0.7,  // Even smaller for background
    blur: '16px', // Increased blur for depth
    // Provides background depth element
  },
  { 
    x: 25,       // Moves right from center
    y: -10,      // Moves up from center
    scale: 0.6,  // Smallest scale for furthest element
    blur: '20px', // Maximum blur for deepest layer
    // Creates furthest background element
  },
]

export default function About() {
  const containerRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLDivElement>(null)

  // Setup scroll-based animations
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  })

  // Define scroll-based transformations
  const opacity = useTransform(scrollYProgress, [0, 0.5], [0, 1])
  const scale = useTransform(scrollYProgress, [0, 0.5], [0.8, 1])
  const y = useTransform(scrollYProgress, [0, 0.5, 1], [100, 0, -100])

  return (
    <section 
      ref={containerRef}
      className="relative min-h-[60vh] overflow-hidden bg-white py-24"
    >
      {/* Background images with depth of field effect */}
      <div className="absolute inset-0 overflow-hidden">
        {imagePositions.map((pos, index) => (
          <motion.div
            key={index}
            className="absolute left-1/2 top-1/2 h-64 w-64"
            style={{
              // Horizontal parallax movement
              x: useTransform(scrollYProgress, 
                [0, 1], 
                [0, pos.x * 20] // Multiplied for more dramatic movement
              ),
              // Vertical parallax movement
              y: useTransform(scrollYProgress, 
                [0, 1], 
                [0, pos.y * 20] // Multiplied for more dramatic movement
              ),
              // Scale changes on scroll
              scale: useTransform(scrollYProgress,
                [0, 1],
                [1, pos.scale]
              ),
              // Blur effect for depth
              filter: `blur(${pos.blur})`,
              // Fade effect while scrolling
              opacity: useTransform(scrollYProgress,
                [0, 0.5, 1],
                [0, 0.15, 0]
              ),
            }}
          >
            <div 
              className="h-full w-full rounded-2xl bg-black/30"
              style={{
                transform: 'translate(-50%, -50%)', // Center the element
              }}
            />
          </motion.div>
        ))}
      </div>

      {/* Animated background blur elements */}
      <div className="absolute inset-0">
        <motion.div
          style={{ opacity }}
          className="absolute left-1/4 top-1/4 h-64 w-64 rounded-full bg-black/[0.03] blur-3xl"
        />
        <motion.div
          style={{ opacity }}
          className="absolute right-1/4 top-2/3 h-64 w-64 rounded-full bg-black/[0.03] blur-3xl"
        />
      </div>

      {/* Main content container */}
      <div className="relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            ref={textRef}
            style={{ 
              opacity,
              scale,
              y
            }}
            className="relative mx-auto max-w-3xl text-center"
          >
            {/* Main text content */}
            <div className="relative">
              <motion.p
                className="text-balance text-xl font-bold leading-relaxed text-black md:text-2xl lg:text-3xl"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                Global Models provides campaigns, models, and influencers to businesses all over the world.
              </motion.p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

