'use client'

import { motion, useSpring } from "framer-motion"
import { useEffect, useState } from "react"
import localFont from 'next/font/local'

// Load Montserrat font
const montserrat = localFont({
  src: '../fonts/Montserrat-Bold.woff2',
  display: 'swap',
})

export default function Loading() {
  const [progress, setProgress] = useState(0)
  const [isComplete, setIsComplete] = useState(false)
  const springProgress = useSpring(0, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  })

  useEffect(() => {
    // Simulate loading progress
    const timer = setTimeout(() => {
      springProgress.set(100)
      setProgress(100)
    }, 1500)

    return () => clearTimeout(timer)
  }, [springProgress])

  useEffect(() => {
    // Add delay after 100% before hiding
    if (progress === 100) {
      const timer = setTimeout(() => {
        setIsComplete(true)
      }, 800) // Pause after completion
      return () => clearTimeout(timer)
    }
  }, [progress])

  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: isComplete ? 0 : 1 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-white"
      onAnimationComplete={() => {
        if (isComplete) {
          document.body.style.overflow = 'auto'
        }
      }}
    >
      <div className="relative px-4">
        <h1
          className={`text-center text-[8vw] font-bold tracking-wider sm:text-[6vw] md:text-[4vw] lg:text-[3vw] ${montserrat.className}`}
          style={{
            color: 'white',
            textShadow: '-1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000',
          }}
        >
          GLOBAL MODELS
          <motion.div
            className="absolute inset-0 overflow-hidden whitespace-nowrap text-center"
            style={{
              color: 'black',
              textShadow: 'none',
            }}
            initial={{ width: '0%' }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
          >
            GLOBAL MODELS
          </motion.div>
        </h1>
      </div>
    </motion.div>
  )
}

