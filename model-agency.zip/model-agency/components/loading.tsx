'use client'

import { motion } from "framer-motion"
import { useEffect, useState } from "react"
import localFont from 'next/font/local'

const montserrat = localFont({
  src: '../fonts/Montserrat-Bold.woff2',
  display: 'swap',
})

export default function Loading() {
  const [isComplete, setIsComplete] = useState(false)

  useEffect(() => {
    // Ensure content is loaded before starting animation
    const timer = setTimeout(() => {
      setIsComplete(true)
    }, 2500)
    return () => clearTimeout(timer)
  }, [])

  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: isComplete ? 0 : 1 }}
      transition={{ duration: 0.8 }}
      onAnimationComplete={() => {
        if (isComplete) {
          document.body.style.overflow = 'auto'
        }
      }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-white"
    >
      <motion.h1
        className={`text-[8vw] font-bold tracking-wider sm:text-[6vw] md:text-[4vw] lg:text-[3vw] ${montserrat.className}`}
        initial={{ color: '#FFFFFF' }}
        animate={{ color: '#000000' }}
        transition={{ duration: 2, ease: "easeInOut" }}
      >
        GLOBAL MODELS
      </motion.h1>
    </motion.div>
  )
}

