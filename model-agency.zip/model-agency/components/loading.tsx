'use client'

import { motion, useSpring } from "framer-motion"
import { useEffect, useState } from "react"

export default function Loading() {
  const [progress, setProgress] = useState(0)
  const springProgress = useSpring(0, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  })

  useEffect(() => {
    // Simulate loading progress
    const timer = setTimeout(() => {
      springProgress.set(100)
      setProgress(100)
    }, 1000)

    return () => clearTimeout(timer)
  }, [springProgress])

  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: progress === 100 ? 0 : 1 }}
      transition={{ duration: 0.5, delay: 0.5 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-white"
      onAnimationComplete={() => {
        if (progress === 100) {
          document.body.style.overflow = 'auto'
        }
      }}
    >
      <div className="relative">
        <h1
          className="text-4xl font-bold tracking-wider md:text-6xl"
          style={{
            fontFamily: 'Montserrat, sans-serif',
            WebkitTextStroke: '1px black',
            color: 'white',
          }}
        >
          GLOBAL MODELS
          <motion.div
            className="absolute inset-0 overflow-hidden whitespace-nowrap"
            style={{
              WebkitTextStroke: '0px',
              color: 'black',
              clipPath: 'inset(0 0 0 0)',
            }}
            initial={{ width: '0%' }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 1, ease: "easeInOut" }}
          >
            GLOBAL MODELS
          </motion.div>
        </h1>
      </div>
    </motion.div>
  )
}

