'use client'

import { motion } from "framer-motion"

export default function Loading() {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: 0 }}
      transition={{ duration: 1, delay: 2.5 }} // Total animation duration
      className="fixed inset-0 z-50 flex items-center justify-center bg-white"
    >
      <motion.h1
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2 }}
        className="text-4xl font-bold tracking-wider md:text-6xl"
        style={{
          fontFamily: 'Montserrat, sans-serif',
          WebkitTextFillColor: 'black',
          WebkitTextStroke: '1px black',
        }}
      >
        <motion.span
          initial={{ color: "white" }}
          animate={{ color: "black" }}
          transition={{ duration: 2 }}
        >
          GLOBAL MODELS
        </motion.span>
      </motion.h1>
    </motion.div>
  )
}

