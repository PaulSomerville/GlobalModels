'use client'

import { motion } from "framer-motion"
import { useEffect, useState } from "react"
import localFont from 'next/font/local'

const montserrat = localFont({
  src: '../fonts/Montserrat-Bold.woff2',
  display: 'swap',
})

export default function Loading() {
  const [progress, setProgress] = useState(0)
  const [isComplete, setIsComplete] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setProgress(100)
    }, 1500)

    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    if (progress === 100) {
      const timer = setTimeout(() => {
        setIsComplete(true)
      }, 800)
      return () => clearTimeout(timer)
    }
  }, [progress])

  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: isComplete ? 0 : 1 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-white"
      onAnimationComplete={() => {
        if (isComplete) {
          document.body.style.overflow = 'auto'
        }
      }}
    >
      <motion.h1
        className={`text-[8vw] font-bold tracking-wider sm:text-[6vw] md:text-[4vw] lg:text-[3vw] ${montserrat.className}`}
        animate={{
          color: progress === 100 ? '#000000' : '#FFFFFF'
        }}
        transition={{ duration: 1.5, ease: "easeInOut" }}
      >
        GLOBAL MODELS
      </motion.h1>
    </motion.div>
  )
}

