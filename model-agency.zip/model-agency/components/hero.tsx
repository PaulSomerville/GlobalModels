'use client'

import { useRef, useEffect } from 'react'
import { motion } from 'framer-motion'

export default function Hero() {
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = 0.75 // Slow down the video slightly
    }
  }, [])

  const scrollToContact = () => {
    const contactSection = document.querySelector('#contact-section')
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <section className="relative h-screen w-full overflow-hidden">
      <div className="absolute inset-0">
        <video
          ref={videoRef}
          autoPlay
          loop
          muted
          playsInline
          className="h-full w-full object-cover"
        >
          <source src="/hero-video.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
        <div className="absolute inset-0 bg-black/30" /> {/* Overlay for better text visibility */}
      </div>

      <div className="absolute left-4 top-4 z-10 text-white md:left-8 md:top-8">
        <h1 className="text-xl font-bold tracking-wider">GLOBAL MODELS</h1>
      </div>
      
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-center text-white"
        >
          <h2 className="mb-2 text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">
            GLOBAL MODELS
          </h2>
          <p className="mb-8 text-lg font-light tracking-wider sm:text-xl md:text-2xl">
            INTERNATIONAL MODELS & INFLUENCERS
          </p>
          
          <motion.button
            onClick={scrollToContact}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ 
              delay: 1,
              type: "spring",
              stiffness: 100,
              damping: 20
            }}
            whileHover={{ 
              y: -5,
              boxShadow: "0 10px 30px rgba(0,0,0,0.2)"
            }}
            whileTap={{ scale: 0.95 }}
            className="group rounded-full border border-white/30 bg-white/10 px-6 py-3 text-sm backdrop-blur-sm transition-all hover:bg-white/20"
          >
            <span className="relative inline-flex items-center gap-2">
              Contact Us
              <motion.span
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.2 }}
                className="inline-block"
              >
                →
              </motion.span>
            </span>
          </motion.button>
        </motion.div>
      </div>
    </section>
  )
}

