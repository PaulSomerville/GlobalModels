'use client'

import { useRef, useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

export default function Hero() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768)
    }
    
    checkMobile()
    window.addEventListener('resize', checkMobile)
    
    if (videoRef.current) {
      videoRef.current.playbackRate = 0.75
    }

    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  const scrollToContact = () => {
    const contactSection = document.querySelector('#contact-section')
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <section className="relative h-screen w-full overflow-hidden bg-black">
      {/* Video Container */}
      <div className="relative h-full w-full md:flex md:items-center md:justify-center">
        {/* Side Panels - Only visible on desktop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.7 }}
          className="hidden md:block absolute inset-y-0 left-0 w-1/4 bg-gradient-to-r from-black to-transparent"
        />
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.7 }}
          className="hidden md:block absolute inset-y-0 right-0 w-1/4 bg-gradient-to-l from-black to-transparent"
        />

        {/* Video */}
        <div className={`relative h-full ${isMobile ? 'w-full' : 'w-[40vh] min-w-[300px] max-w-[500px]'}`}>
          <video
            ref={videoRef}
            autoPlay
            loop
            muted
            playsInline
            className="h-full w-full object-cover"
            poster="/video-poster.jpg"
          >
            <source src="https://asset.cloudinary.com/djvd9w1vv/832f8b28bd3605424a5c4dac06365683" type="video/mp4" />
          </video>
          <div className="absolute inset-0 bg-black/20" />
        </div>
      </div>

      {/* Content Overlay */}
      <div className="absolute left-4 top-4 z-10 text-white md:left-8 md:top-8">
        <h1 className="text-xl font-bold tracking-wider">GLOBAL MODELS</h1>
      </div>
      
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-center text-white"
        >
          <h2 className="mb-2 text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">
            GLOBAL MODELS
          </h2>
          <p className="mb-8 text-lg font-light tracking-wider sm:text-xl md:text-2xl">
            INTERNATIONAL MODELS & INFLUENCERS
          </p>
          
          <motion.button
            onClick={scrollToContact}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ 
              delay: 1,
              type: "spring",
              stiffness: 100,
              damping: 20
            }}
            whileHover={{ 
              y: -5,
              boxShadow: "0 10px 30px rgba(0,0,0,0.2)"
            }}
            whileTap={{ scale: 0.95 }}
            className="pointer-events-auto group rounded-full border border-white/30 bg-white/10 px-6 py-3 text-sm backdrop-blur-sm transition-all hover:bg-white/20"
          >
            <span className="relative inline-flex items-center gap-2">
              Contact Us
              <motion.span
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.2 }}
                className="inline-block"
              >
                →
              </motion.span>
            </span>
          </motion.button>
        </motion.div>
      </div>
    </section>
  )
}

