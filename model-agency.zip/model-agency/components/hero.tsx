'use client'

import { useRef, useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Montserrat } from 'next/font/google'

const montserrat = Montserrat({ subsets: ['latin'], weight: ['400', '700'] })

export default function Hero() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isMobile, setIsMobile] = useState(false)
  const [isVideoLoaded, setIsVideoLoaded] = useState(false)

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768)
    }
    
    checkMobile()
    window.addEventListener('resize', checkMobile)
    
    if (videoRef.current) {
      videoRef.current.playbackRate = 0.75
    }

    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  const handleCanPlay = () => {
    if (videoRef.current) {
      videoRef.current.play()
      setIsVideoLoaded(true)
    }
  }

  const scrollToContact = () => {
    const contactSection = document.querySelector('#contact-section')
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <section className={`${montserrat.className} relative h-screen w-full overflow-hidden bg-black md:bg-white`}>
      <div className="relative h-full w-full md:flex md:items-center md:justify-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.7 }}
          className="hidden md:block absolute inset-y-0 left-0 w-1/4 bg-gradient-to-r from-white to-transparent"
        />
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.7 }}
          className="hidden md:block absolute inset-y-0 right-0 w-1/4 bg-gradient-to-l from-white to-transparent"
        />

        <div className={`relative h-full ${isMobile ? 'w-full' : 'w-[40vh] min-w-[300px] max-w-[500px]'}`}>
          {!isVideoLoaded && (
            <div className="absolute inset-0 bg-white md:bg-gray-200 flex items-center justify-center">
              <div className="w-12 h-12 border-4 border-black border-t-transparent rounded-full animate-spin"></div>
            </div>
          )}
          <video
            ref={videoRef}
            autoPlay
            loop
            muted
            playsInline
            preload="auto"
            onCanPlay={handleCanPlay}
            className={`h-full w-full object-cover transition-opacity duration-500 ${isVideoLoaded ? 'opacity-100' : 'opacity-0'}`}
          >
            <source 
              src="https://res.cloudinary.com/djvd9w1vv/video/upload/v1733003499/GlobalModels_fwd530.webm" 
              type="video/webm"
            />
            <source 
              src="https://res.cloudinary.com/djvd9w1vv/video/upload/v1733003499/GlobalModels_fwd530.mp4" 
              type="video/mp4"
            />
            Your browser does not support the video tag.
          </video>
          <div className="absolute inset-0 bg-black/20 md:bg-transparent" />
        </div>
      </div>
      
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-center text-white"
        >
          <h2 className="mb-2 text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl" style={{ textShadow: '0 2px 4px rgba(0, 0, 0, 0.5)' }}>
            GLOBAL MODELS
          </h2>
          <p className="mb-8 text-base font-light tracking-wider sm:text-lg md:text-xl" style={{ textShadow: '0 2px 4px rgba(0, 0, 0, 0.5)' }}>
            INTERNATIONAL MODELS & INFLUENCERS
          </p>
          
          <motion.button
            onClick={scrollToContact}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ 
              delay: 1,
              type: "spring",
              stiffness: 100,
              damping: 20
            }}
            whileHover={{ 
              y: -5,
              boxShadow: "0 10px 30px rgba(0, 0, 0, 0.2)"
            }}
            whileTap={{ scale: 0.95 }}
            className="pointer-events-auto group rounded-full border border-white/30 bg-black/10 px-6 py-3 text-sm backdrop-blur-sm transition-all hover:bg-black/20"
          >
            <span className="relative inline-flex items-center gap-2 text-white">
              Contact Us
              <motion.span
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.2 }}
                className="inline-block"
              >
                →
              </motion.span>
            </span>
          </motion.button>
        </motion.div>
      </div>
    </section>
  )
}

