'use client'

import { useRef, useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import Image from 'next/image'

export default function Hero() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isMobile, setIsMobile] = useState(false)
  const [isVideoLoaded, setIsVideoLoaded] = useState(false)
  const [isVideoError, setIsVideoError] = useState(false)

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768)
    }
    
    checkMobile()
    window.addEventListener('resize', checkMobile)
    
    if (videoRef.current) {
      videoRef.current.playbackRate = 0.75
    }

    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  const handleVideoLoad = () => {
    setIsVideoLoaded(true)
  }

  const handleVideoError = () => {
    setIsVideoError(true)
    console.error('Video failed to load')
  }

  const scrollToContact = () => {
    const contactSection = document.querySelector('#contact-section')
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <section className="relative h-screen w-full overflow-hidden bg-black">
      <div className="relative h-full w-full md:flex md:items-center md:justify-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.7 }}
          className="hidden md:block absolute inset-y-0 left-0 w-1/4 bg-gradient-to-r from-black to-transparent"
        />
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.7 }}
          className="hidden md:block absolute inset-y-0 right-0 w-1/4 bg-gradient-to-l from-black to-transparent"
        />

        <div className={`relative h-full ${isMobile ? 'w-full' : 'w-[40vh] min-w-[300px] max-w-[500px]'}`}>
          {!isVideoLoaded && !isVideoError && (
            <div className="absolute inset-0 bg-black flex items-center justify-center">
              <div className="w-12 h-12 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
            </div>
          )}
          {!isVideoError ? (
            <video
              ref={videoRef}
              autoPlay
              loop
              muted
              playsInline
              onLoadedData={handleVideoLoad}
              onError={handleVideoError}
              className={`h-full w-full object-cover ${isVideoLoaded ? 'opacity-100' : 'opacity-0'}`}
              poster="/video-poster.jpg"
            >
              <source src="https://asset.cloudinary.com/djvd9w1vv/832f8b28bd3605424a5c4dac06365683" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          ) : (
            <Image
              src="/video-poster.jpg"
              alt="Global Models"
              layout="fill"
              objectFit="cover"
              priority
            />
          )}
          <div className="absolute inset-0 bg-black/20" />
        </div>
      </div>

      <div className="absolute left-4 top-4 z-10 text-white md:left-8 md:top-8">
        <h1 className="text-xl font-bold tracking-wider">GLOBAL MODELS</h1>
      </div>
      
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-center text-white"
        >
          <h2 className="mb-2 text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">
            GLOBAL MODELS
          </h2>
          <p className="mb-8 text-lg font-light tracking-wider sm:text-xl md:text-2xl">
            INTERNATIONAL MODELS & INFLUENCERS
          </p>
          
          <motion.button
            onClick={scrollToContact}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ 
              delay: 1,
              type: "spring",
              stiffness: 100,
              damping: 20
            }}
            whileHover={{ 
              y: -5,
              boxShadow: "0 10px 30px rgba(0,0,0,0.2)"
            }}
            whileTap={{ scale: 0.95 }}
            className="pointer-events-auto group rounded-full border border-white/30 bg-white/10 px-6 py-3 text-sm backdrop-blur-sm transition-all hover:bg-white/20"
          >
            <span className="relative inline-flex items-center gap-2">
              Contact Us
              <motion.span
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.2 }}
                className="inline-block"
              >
                →
              </motion.span>
            </span>
          </motion.button>
        </motion.div>
      </div>
    </section>
  )
}

