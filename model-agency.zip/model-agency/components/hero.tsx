'use client'

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"

const slides = [
  {
    id: 1,
    image: "/placeholder.svg?height=800&width=600",
    title: "GLOBAL MODELS",
    subtitle: "INTERNATIONAL MODELS",
  },
  {
    id: 2,
    image: "/placeholder.svg?height=800&width=600",
    title: "GLOBAL MODELS",
    subtitle: "INTERNATIONAL CAMPAIGNS",
  },
  {
    id: 3,
    image: "/placeholder.svg?height=800&width=600",
    title: "GLOBAL MODELS",
    subtitle: "UGC & INFLUENCERS",
  },
]

export default function Hero() {
  const [current, setCurrent] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  return (
    <section className="relative h-screen w-full overflow-hidden">
      <div className="absolute left-4 top-4 z-10 text-white md:left-8 md:top-8">
        <h1 className="text-xl font-bold tracking-wider">GLOBAL MODELS</h1>
      </div>
      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.7 }}
          className="absolute inset-0"
        >
          <Image
            src={slides[current].image}
            alt={slides[current].title}
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-black/20" />
        </motion.div>
      </AnimatePresence>
      
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-center text-white"
        >
          <h1 className="mb-2 text-6xl font-bold tracking-tighter sm:text-7xl lg:text-8xl">
            {slides[current].title}
          </h1>
          <p className="text-lg font-light tracking-wider">{slides[current].subtitle}</p>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <div className="flex gap-2">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrent(index)}
              className={`h-2 w-8 rounded-full transition-all ${
                current === index ? "bg-white" : "bg-white/50"
              }`}
            >
              <span className="sr-only">Go to slide {index + 1}</span>
            </button>
          ))}
        </div>
      </motion.div>
    </section>
  )
}

